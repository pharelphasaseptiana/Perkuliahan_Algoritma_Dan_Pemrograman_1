from datetime import datetime

def tambah_catatan():
    catatan = input("Masukkan catatan: ")
    waktu = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open("notes.txt", "a") as file:
        file.write(f"[{waktu}] {catatan}\n")
    print("Catatan berhasil disimpan.\n")

def tampilkan_catatan():
    try:
        with open("notes.txt", "r") as file:
            isi = file.read()
            print("\n--- DAFTAR CATATAN ---")
            print(isi)
    except FileNotFoundError:
        print("Belum ada catatan.\n")

def cari_catatan():
    kata_kunci = input("Masukkan kata kunci: ")
    try:
        with open("notes.txt", "r") as file:
            print("\n--- HASIL PENCARIAN ---")
            for baris in file:
                if kata_kunci.lower() in baris.lower():
                    print(baris.strip())
    except FileNotFoundError:
        print("File catatan belum ada.\n")

def menu():
    while True:
        print("=== APLIKASI CATATAN ===")
        print("1. Tambah Catatan")
        print("2. Lihat Semua Catatan")
        print("3. Cari Catatan")
        print("4. Keluar")
        pilihan = input("Pilih menu (1-4): ")
        if pilihan == "1":
            tambah_catatan()
        elif pilihan == "2":
            tampilkan_catatan()
        elif pilihan == "3":
            cari_catatan()
        elif pilihan == "4":
            print("Program selesai.")
            break
        else:
            print("Pilihan tidak valid.\n")
            
menu()

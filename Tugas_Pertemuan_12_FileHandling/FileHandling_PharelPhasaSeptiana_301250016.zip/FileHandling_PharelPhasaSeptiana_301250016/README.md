# Aplikasi Catatan Sederhana (Simple Notepad)

## Deskripsi
Aplikasi berbasis console menggunakan bahasa Python untuk menyimpan catatan ke dalam file teks secara permanen menggunakan konsep File Handling.

## Fitur
1. Menambah catatan (append)
2. Menampilkan semua catatan
3. Mencari catatan berdasarkan kata kunci
4. Penyimpanan data menggunakan file notes.txt
5. Setiap catatan dilengkapi timestamp

## Teknologi
- Python
- File I/O (read, write, append)

## Cara Menjalankan
1. Buka terminal
2. Jalankan perintah:
   python main.py
3. Ikuti menu yang tersedia

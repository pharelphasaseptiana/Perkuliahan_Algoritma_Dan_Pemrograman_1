def menu():
    print("\n=== BUKU TELEPON ===")
    print("1. Tambah Kontak")
    print("2. Lihat Kontak")
    print("3. Cari Kontak")
    print("4. Keluar")

def tambah_kontak():
    nama = input("Nama   : ")
    nomor = input("Nomor  : ")
    with open("kontak.txt", "a") as file:
        file.write(nama + " - " + nomor + "\n")
    print("Kontak berhasil disimpan.")

def lihat_kontak():
    try:
        print("\nDaftar Kontak:")
        with open("kontak.txt", "r") as file:
            for kontak in file:
                print(kontak.strip())
    except FileNotFoundError:
        print("Belum ada kontak.")

def cari_kontak():
    keyword = input("Cari nama: ").lower()
    ditemukan = False
    try:
        with open("kontak.txt", "r") as file:
            for kontak in file:
                if keyword in kontak.lower():
                    print(kontak.strip())
                    ditemukan = True
        if not ditemukan:
            print("Kontak tidak ditemukan.")
    except FileNotFoundError:
        print("Data kontak belum ada.")

if __name__ == "__main__":
    while True:
        menu()
        pilihan = input("Pilih menu (1-4): ")

        if pilihan == "1":
            tambah_kontak()
        elif pilihan == "2":
            lihat_kontak()
        elif pilihan == "3":
            cari_kontak()
        elif pilihan == "4":
            print("Program selesai.")
            break
        else:
            print("Pilihan tidak valid.")

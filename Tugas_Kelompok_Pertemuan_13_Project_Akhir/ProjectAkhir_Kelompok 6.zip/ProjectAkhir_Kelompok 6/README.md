# Aplikasi Manajemen Buku Telepon / Kontak
Program ini merupakan aplikasi Sistem Manajemen Kontak Sederhana (Buku Telepon) berbasis konsol. Aplikasi ini memungkinkan pengguna untuk menambahkan, melihat, dan mencari data kontak yang disimpan secara permanen dalam file teks.
  
## Konsep yang Terintegrasi
-Percabangan (if-else)
Digunakan untuk pemilihan menu, penanganan FileNotFoundError, dan penentuan apakah kontak ditemukan saat pencarian.
-Perulangan (for/while)
Digunakan while True untuk menjalankan menu utama dan for loop untuk membaca setiap baris kontak dari file.
-List dan String
Menggunakan string untuk menyimpan data kontak (Nama - Nomor) dan operasi string untuk pencarian.
-Fungsi
Program dipecah menjadi fungsi-fungsi modular yaitu menu, tambah_kontak, lihat_kontak, dan cari_kontak agar struktur kode lebih rapi.
-File Handling
Data disimpan secara permanen dalam file kontak.txt. Fungsi tambah_kontak menggunakan mode append dan fungsi lihat_kontak serta cari_kontak menggunakan mode read.

## Cara Menjalankan
1. Buka terminal
2. Jalankan perintah:
   python main.py
3. Ikuti instruksi menu yang muncul di konsol. Data kontak akan otomatis disimpan ke dalam file kontak.txt.

## Fitur Program
1. Menambahkan kontak baru
2. Menampilkan seluruh kontak
3. Mencari kontak berdasarkan nama
4. Penyimpanan data menggunakan file teks

## Struktur File
├── main.py
├── kontak.txt
└── README.md
